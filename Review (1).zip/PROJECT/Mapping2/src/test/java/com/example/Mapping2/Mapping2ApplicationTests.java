package com.example.Mapping2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mapping2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
